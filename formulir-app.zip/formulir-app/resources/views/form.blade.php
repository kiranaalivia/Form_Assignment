<!DOCTYPE html>
<html>
<head>
    <title>Form Example</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        h1 {
            background-color: #3498db;
            color: #fff;
            padding: 20px;
        }

        form {
            width: 60%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="file"] {
            padding: 5px;
        }

        button[type="submit"] {
            background-color: #3498db;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #2980b9;
        }

        .alert {
            background-color: #27ae60;
            color: #fff;
            padding: 10px;
            margin-bottom: 15px;
        }

        .alert-danger {
            background-color: #e74c3c;
        }
    </style>
</head>
<body>
    <h1>Form Example</h1>
    
    @if(session('success'))
        <div class="alert">
            {{ session('success') }}
        </div>
    @endif

    <form action="/form" method="POST" enctype="multipart/form-data">
        @csrf

        <label for="name">Name</label>
        <input type="text" name="name" value="{{ old('name') }}">
        @error('name')
            <p class="alert alert-danger">{{ $message }}</p>
        @enderror

        <label for="email">Email</label>
        <input type="email" name="email" value="{{ old('email') }}">
        @error('email')
            <p class="alert alert-danger">{{ $message }}</p>
        @enderror

        <label for="age">Age</label>
        <input type="number" name="age" value="{{ old('age') }}">
        @error('age')
            <p class="alert alert-danger">{{ $message }}</p>
        @enderror

        <label for="image">Image (Max 2MB, .jpeg/.jpg/.png)</label>
        <input type="file" name="image">
        @error('image')
            <p class="alert alert-danger">{{ $message }}</p>
        @enderror

        <label for="price">Price (Between 2.50 and 99.99)</label>
        <input type="number" step="0.01" name="price" value="{{ old('price') }}">
        @error('price')
            <p class="alert alert-danger">{{ $message }}</p>
        @enderror

        <button type="submit">Submit</button>
    </form>
    @if (session('success'))
    @include('success')
    @endif
</body>
</html>
