<!-- resources/views/success.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Form Submission Successful</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #3498db;
        }

        h2 {
            color: #333;
        }

        img {
            max-width: 100%;
            height: auto;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Form Submission Successful</h1>

        @if (session('success'))
            <h2>Name: {{ session('name') }}</h2>
            <h2>Email: {{ session('email') }}</h2>
            <h2>Age: {{ session('age') }}</h2>
            <h2>Price: ${{ session('price') }}</h2>

            <h2>Uploaded Image:</h2>
            <img src="{{ asset('images/' . session('image')) }}" alt="Uploaded Image">
        @endif
    </div>
</body>
</html>
